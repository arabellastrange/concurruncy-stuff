package bank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import bank.system.Account;
import bank.system.BankSystem;
import bank.system.Customer;
import bank.system.PlatinumAccount;
import bank.system.UnlimitedAccounts;

public class ConcurrentTestingSystem {
	
	public static void main(String args[]){
		
		
		
		
		String[] testTargetsDW = {"0D1W", "0D1W", "0D1D",
		                          "0W0D", "0W1W", "0W1D",
		                          "1D0W", "1D0D", "1D1W",
		                          "1W0D", "1W0W", "1W1D"};
		
		ArrayList<String> ttDW = new ArrayList<String>(Arrays.asList(testTargetsDW));
		
		                        
		String[] testTargetsHS = {"0S0U", "0S1U", "0S1S",
		                          "0U1U", "0U1S", "0U0S",
		                          "1S0U", "1S0S", "1S1U",
		                          "1U0S", "1U0U", "1U1S"};
		
		ArrayList<String> ttHS = new ArrayList<String>(Arrays.asList(testTargetsHS));
		
		int i = 0;
		
		boolean bugFoundDW = false;
		boolean bugFoundHS = false;
		
		System.out.println("Finding Bugs For Balance Lock:");
		System.out.println("Test Target:");
		System.out.println(ttDW);
			
		while(!ttDW.isEmpty() && i < 1000){
			
			
			
			BankSystem.getBank().printBankSystemInfo();

	        Customer customer = new Customer("" + i,  BankSystem.getBank().getEmployee(0));
	        BankSystem.getBank().addCustomer(customer);
	        BankSystem.getBank().printBankSystemInfo();

	        Account accountA = new PlatinumAccount(400);
	        customer.requestNewAccount(accountA);
	        BankSystem.getBank().printBankSystemInfo();

	        List<String> list = new ArrayList<String>();
	        
	        Thread t0 = new Thread(new WithdrawDepositDriver(customer, accountA, list));
	        Thread t1 = new Thread(new WithdrawDepositDriver(customer, accountA, list));
	        
	        
	        t0.start();
	        
	        t1.start();
	        try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        //System.out.println(accountA.checkBal());
	        if(Double.compare(450.00, accountA.checkBal()) == 0){
	        	//System.out.println("$" + "$");
	        	ArrayList<String> pairs = new ArrayList<String>();
	        	
	        	for(int y = 0; y < list.size() - 1; y++)
	        	{
	        		pairs.add(list.get(y) + list.get(y + 1));
	        		//System.out.println("$" + list.get(y) + "$");
	        		
	        		
	        	}
	        	
	        	for(int y = 0; y < pairs.size(); y++)
	        	{
	        		//pairs.add(list.get(i) + list.get(i + 1));
	        		//System.out.println("$" + pairs.get(y) + "$");
	        		ttDW.remove(pairs.get(y));
	        		//System.out.println(ttDW.size());
	        		//System.out.println(ttDW.isEmpty());
	        		
	        	}
	        	
	        	//List has results => Change to correct format
	        	
	        	
	        	//Test returns successfully 
	        	//Remove result interleaving from testTargets
	        	//ttDW.remove();
	        } else{
	        	// Test ended with wrong result, test failed, bug found
	        	//System.out.println("Test Failed, Bug present");
	        	bugFoundDW = true;
	        	break;
	        }
			System.out.println(ttDW);
			i++;
		}
		
		if(bugFoundDW){
			System.out.println("Test Failed, Concurrency Bug Present");
		} else{
			
			
			i = 0;
			
			System.out.println("Finding Bugs For Overdraft Lock:");
			System.out.println("Test Target:");
			System.out.println(ttHS);
			
			while(!ttHS.isEmpty() && i < 1000){
				
				BankSystem.getBank().printBankSystemInfo();

		        Customer customer = new Customer("S" + i,  BankSystem.getBank().getEmployee(0));
		        BankSystem.getBank().addCustomer(customer);
		        BankSystem.getBank().printBankSystemInfo();

		        UnlimitedAccounts accountA = new PlatinumAccount(400);
		        customer.requestNewAccount(accountA);
		        BankSystem.getBank().printBankSystemInfo();

		        List<String> list = new ArrayList<String>();
		        
		        Thread t0 = new Thread(new OverdraftDriver(customer, accountA, list));
		        Thread t1 = new Thread(new OverdraftDriver(customer, accountA, list));
		        
		        
		        t0.start();
		        t1.start();
		        try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		        
		        //System.out.println(accountA.getOverdraft() + "==" + accountA.hasOverdraft());
		        if((Double.compare(800.00, accountA.getOverdraft()) == 0 && accountA.hasOverdraft() == true)
		        		|| (Double.compare(0.00, accountA.getOverdraft()) == 0 && accountA.hasOverdraft() == false)){
		        	ArrayList<String> pairs = new ArrayList<String>();
		        	
		        	for(int y = 0; y < list.size() - 1; y++)
		        	{
		        		pairs.add(list.get(y) + list.get(y + 1));
		        		//System.out.println(list.get(y));
		        	}
		        	
		        	for(int y = 0; y < pairs.size(); y++)
		        	{
		        		ttHS.remove(pairs.get(y));
		        		
		        	}
		        	System.out.println(ttHS);
		        } else{
		        	bugFoundHS = true;
		        	break;
		        }
				
				i++;
			}
		}
		
		if(bugFoundHS || bugFoundDW){
			System.out.println("Bug Found");
		}
    }	
}
