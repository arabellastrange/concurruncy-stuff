package bank;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import bank.system.*;

public class OverdraftDriver implements Runnable {
    private static Customer customer;
    private static Account account;
    private List<String> strList;

    public OverdraftDriver(Customer cus, Account acc, List<String> list) {
		customer = cus;
		account = acc;
		strList = list;
	}

    @Override
    public void run() {
    	if(ThreadLocalRandom.current().nextInt(0, 2) == 0)
		{
    		//strList.add("ODDriver");
			customer.requestOverdraft((UnlimitedAccounts) account, 800, strList);
			customer.requestCancelOverdraft((UnlimitedAccounts) account, strList);
//		    try {
//		        customer.withdraw(account, 300);
//		    } catch (InterruptedException e) {
//		        System.out.println("Balance too low, never replenished, can't wait anymore");
//		    }
			
		} else{
			//strList.add("ODDriver");
//			try {
//		        strList.add(customer.withdraw(account, 300));
//		    } catch (InterruptedException e) {
//		        System.out.println("Balance too low, never replenished, can't wait anymore");
//		    }
			customer.requestCancelOverdraft((UnlimitedAccounts) account, strList);
			customer.requestOverdraft((UnlimitedAccounts) account, 800, strList);
			
		}
        
    }
}
