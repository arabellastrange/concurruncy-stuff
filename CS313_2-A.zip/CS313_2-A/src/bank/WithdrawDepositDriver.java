package bank;

import bank.system.*;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class WithdrawDepositDriver implements Runnable{
    private static Customer customer;
    private static Account accountA;
    private List<String> strList;

    public WithdrawDepositDriver(Customer cus, Account acc, List<String> list) {
		customer = cus;
    	accountA = acc;
    	strList = list;
	}


	@Override
	public void run() {
		try {
			//String string = "";
        	if(ThreadLocalRandom.current().nextInt(0, 2) == 0)
        	{        		
        		strList.add(customer.deposit(accountA, 150));
        		strList.add(customer.withdraw(accountA, 125));
        		
        	} else{
        		strList.add(customer.withdraw(accountA, 125));
        		strList.add(customer.deposit(accountA, 150));        		
        	}
        	//strList.add(string);
            //System.out.println(string);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
		
	}

}