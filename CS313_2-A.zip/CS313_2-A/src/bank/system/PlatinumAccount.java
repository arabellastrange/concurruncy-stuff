package bank.system;

import java.util.ArrayList;
import java.util.List;

public class PlatinumAccount extends UnlimitedAccounts {
    private double fee;

    public PlatinumAccount(double initialBalance) {
        super(initialBalance);
        setInterestRate(0.2);
        setInterestLength(0.25);
        fee = 75;
    }


    public void verifyOverdraft(double amount, List<String> strList) {
    	overdraftLock.lock();
    	try{
    		strList.add((Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "S");
    		setOverdraft(amount, strList);
    		setHasOverdraft(true, strList);
    	}finally{
    		overdraftLock.unlock();
    	}     
    }
    

    public double getAccountFee() {
        return fee;
    }
}
