package bank.system;

import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class UnlimitedAccounts extends Account {
    private Condition balanceTooLow;
    private boolean waitingForMoreMoney = true;
    Lock overdraftLock;
    private double overdraft;
    private boolean hasOverdraft = false;
    private Object o = new Object();

    public UnlimitedAccounts(double initialBalance) {
        super(initialBalance);
        balanceTooLow = balanceLock.newCondition();
        overdraftLock = new ReentrantLock();
    }

    @Override
    public String deposit(double dep) {
    	String string = "";
    	try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(0, 101));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	synchronized(o){
    		balanceLock.lock();
    		string = (Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "D";
    		//System.out.println(string);
    	}
        
        try {
            setBalance(checkBal() + dep);
            //System.out.println("Thread " + Thread.currentThread().getId() + " is attempting to deposit \n" + "\t Deposit successful, deposited: £" + dep);
            balanceTooLow.signalAll();
            return string;
        } finally {
            balanceLock.unlock();
        }
    }

    @Override
    public String withdraw(double amount) throws InterruptedException {
    	String string = "";
    	try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(0, 101));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	synchronized(o){
    		balanceLock.lock();
    		string = (Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "W";
    		//System.out.println(string);
    	}
        try {
            while (isBalanceTooLow(amount)) {
                if (!waitingForMoreMoney) {
                    Thread.currentThread().interrupt();
                }
                waitingForMoreMoney = balanceTooLow.await(10, TimeUnit.SECONDS);
            }
            setBalance(checkBal() - amount);
            //System.out.println("Thread " + Thread.currentThread().getId() + " is attempting to withdraw \n" + "\t Withdrawal Successful, withdrew: £" + amount);
            return string;
        } finally {
            balanceLock.unlock();
        }
    }

    public boolean isBalanceTooLow(double amount) {
        if (hasOverdraft()) {
            if (checkBal() + overdraft <= amount) {
                //System.out.println("Thread " + Thread.currentThread().getId() + " is attempting to withdraw \n" + "\t Balance too low to perform this action will wait for more money");
                return true;
            }
        } else {
            if (checkBal() <= 0) {
                //System.out.println("Thread " + Thread.currentThread().getId() + " is attempting to withdraw \n" + "\t Balance too low to perform this action will wait for more money");
                return true;
            }
        }
        return false;
    }

    public boolean hasOverdraft() {
    	
        return hasOverdraft;
    }

    public void setHasOverdraft(boolean overdraft, List<String> strList) {
    	try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(0, 101));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	synchronized(o){
    		overdraftLock.lock();
    		//strList.add((Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "H");
    	}
        try {
            hasOverdraft = overdraft;
        } finally {
            overdraftLock.unlock();
        }

    }

    public double getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(double amount, List<String> strList) {
    	try {
			Thread.sleep(ThreadLocalRandom.current().nextInt(0, 101));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	synchronized(o){
    		overdraftLock.lock();
    		//strList.add((Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "S");
    	}
        try {
            overdraft = amount;
        } finally {
            overdraftLock.unlock();
        }
    }

    @Override
	public void cancelOverdraft(List<String> strList) {
		if(checkBal() > 0){
			overdraftLock.lock();
        	try{
        		strList.add((Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "U");
        		setOverdraft(0, strList);
        		setHasOverdraft(false, strList);
        	}finally{
        		overdraftLock.unlock();
        	} 
			
		}
		
	}
}
