package bank.system;

import java.util.ArrayList;
import java.util.List;

public class CurrentAccount extends UnlimitedAccounts {
    public CurrentAccount(double initialBalance) {
        super(initialBalance);
        setInterestRate(0.01);
        setInterestLength(1);
    }

    public void verifyOverdraft(double amount, List<String> strList) {
        if (getOverdraft() <= 1000 || amount <= 1000) {
        	overdraftLock.lock();
        	try{
        		strList.add((Thread.currentThread().getId()%2 == 0 ? 0 : 1) + "S");
        		setOverdraft(amount, strList);
        		setHasOverdraft(true, strList);
        	}finally{
        		overdraftLock.unlock();
        	}        	
        }
        System.out.println("You cannot set an overdraft of over £1000 with a current account, you may instead use a platinum account");
    }

}
