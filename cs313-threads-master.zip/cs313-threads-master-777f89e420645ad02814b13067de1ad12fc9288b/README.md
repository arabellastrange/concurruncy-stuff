# CS313 Group Project 1

The project is split into two parts the bank system and thread management. 

## Progress

This document can be used for quick weekly progress notes

## Contributors

Chadha Degachi SE2015 @wyb15135

Martin Kollie @vib15168

Nicolas Andreou CS2015 @dkb15141

Sandeep Singh Dhesi @trb15129
 
Sara Reid CS2015 @szb15123
